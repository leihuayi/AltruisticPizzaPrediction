# Data science projet for predicting Random Acts of Pizza (RAOPred)

## Usage

** Develop with jupyter notebook **
```bash
docker-compose build notebook
docker-compose up notebook
```

** Run tests **
```bash
docker-compose build tests
docker-compose up tests
```